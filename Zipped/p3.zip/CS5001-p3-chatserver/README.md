ADDITIONAL FEATURE

* I've implemented an additional COMMAND for the client.
* Syntax -------> MULTITABLE <number> 
* This command allows the client to input a number and get the multiplication table of that number back.
* It's implemented in "ConnectionHandler.java" file.
* It's given as a switch case along with other commands.
* It's the second last command in the switch case above "default" tag.